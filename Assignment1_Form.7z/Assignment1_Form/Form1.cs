﻿using System;
using System.ComponentModel;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using System.Threading.Tasks;
using System.Drawing;

namespace Assignment1_Form
{
    // TODO: Add variables and fill in code

    /// <summary>
    /// The GUI for playing music and starting two graphical threads
    /// </summary>
    public partial class Form1 : Form
    {
        /// <summary>
        /// COnstructor. 
        /// </summary>
        public Form1()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Let the user choose his favorite music, either .waw or .mp3
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnOpen_Click(object sender, EventArgs e)
        {

        }

        /// <summary>
        /// Display music file in GUI and tell player what to play
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void openFileDialog1_FileOk(object sender, CancelEventArgs e)
        {

        }

        /// <summary>
        /// Start the music maestro!
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnPlay_Click(object sender, EventArgs e)
        {

        }

        /// <summary>
        /// Stop playing
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnMp3Stop_Click(object sender, EventArgs e)
        {

        }

        /// <summary>
        /// Creates a new triangle instance, and a new thread.
        /// Starts that thread.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnRotate_Click(object sender, EventArgs e)
        {

        }

        /// <summary>
        /// Aborts the current triangle thread
        /// Also saves the current position of the triangle, for new starts
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnRotStop_Click(object sender, EventArgs e)
        {

        }

        /// <summary>
        /// If threads are running or waitng at form close, stop threads
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            System.Environment.Exit(System.Environment.ExitCode);
        }

        /// <summary>
        /// Creates a new DisplayName and a new thread
        /// Start the thread
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnDisplay_Click(object sender, EventArgs e)
        {

        }

        /// <summary>
        /// Aborts the display thread.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnDisplayStop_Click(object sender, EventArgs e)
        {

        }

        /// <summary>
        /// If to draw something in game
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            
        }
    }
}
